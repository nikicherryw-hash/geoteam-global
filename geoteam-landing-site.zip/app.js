
(function(){
  const cfg = window.GEOTEAM_CONFIG || {};
  const LS = 'geoteam:cart';
  const $ = s => document.querySelector(s);
  const $$ = s => Array.from(document.querySelectorAll(s));
  const load = () => { try { return JSON.parse(localStorage.getItem(LS)||'{"items":[]}'); } catch { return {items:[]} } };
  const save = (s) => localStorage.setItem(LS, JSON.stringify(s));
  const state = load();

  function add(item){ const f = state.items.find(x=>x.id===item.id); if(f){f.qty += item.qty;} else {state.items.push(item);} save(state); renderCount(); }
  function remove(id){ const i = state.items.findIndex(x=>x.id===id); if(i>=0){state.items.splice(i,1); save(state); render(); renderCount();} }
  function qty(id, q){ const f = state.items.find(x=>x.id===id); if(f){f.qty=q; save(state);} }

  function renderCount(){ const c = state.items.reduce((s,i)=>s+i.qty,0); const el = $('#cart-count'); if(el) el.textContent = c; }
  function openDrawer(){ const d=$('.drawer'); if(d){ d.classList.add('open'); render(); } }
  function closeDrawer(){ const d=$('.drawer'); if(d){ d.classList.remove('open'); } }

  function render(){
    const root = document.querySelector('.drawer .list'); if(!root) return;
    root.innerHTML = state.items.map(it=>`
      <div class="it">
        <img src="${it.image||'assets/globe.svg'}" alt="">
        <div>
          <div style="font-weight:700">${it.title}</div>
          <div style="font-size:12px;color:#6a7b86">SKU: ${it.sku}</div>
          <div style="font-size:12px;color:#0c6e74">${it.price? (it.price+' '+(it.currency||'')) : 'On request'}</div>
        </div>
        <div style="display:grid;gap:6;justify-items:end">
          <input type="number" min="1" value="${it.qty}" data-id="${it.id}" class="q">
          <button data-id="${it.id}" class="rm">Remove</button>
        </div>
      </div>
    `).join('');
    root.querySelectorAll('.q').forEach(inp=> inp.addEventListener('change', e=> qty(e.target.dataset.id, Number(e.target.value)||1)));
    root.querySelectorAll('.rm').forEach(btn=> btn.addEventListener('click', e=> remove(e.target.dataset.id)));
  }

  async function sendRFQ(){
    const btn = document.getElementById('send-rfq'); if(!btn) return;
    btn.disabled = true; btn.textContent = 'Sending...';
    try{
      const payload = {
        to: 'info@geoteam.global',
        subject: 'RFQ — GeoTeam Global website',
        body: 'Requested items:\\n' + state.items.map(i=>`- ${i.title} (SKU ${i.sku}) — qty ${i.qty}`).join('\\n')
      };
      if(cfg.MOCK){
        await new Promise(r=>setTimeout(r, 600));
        alert('RFQ simulated. Set MOCK=false in config.js for real send.');
      }else{
        const res = await fetch(cfg.MAIL_API_URL, {
          method: 'POST',
          headers: {'Content-Type':'application/json', 'X-Api-Key': cfg.MAIL_API_KEY},
          body: JSON.stringify(payload)
        });
        if(!res.ok) throw new Error('Mail API error');
        alert('RFQ sent.');
      }
    }catch(e){
      alert('Error: '+e.message);
    }finally{
      btn.disabled = false; btn.textContent = 'Send RFQ';
    }
  }

  // Expose
  window.GT = { add, openDrawer, sendRFQ };

  document.addEventListener('DOMContentLoaded', ()=>{
    renderCount();
    $$('.add-to-rfq').forEach(b=> b.addEventListener('click', e=>{
      const el = e.currentTarget;
      add({ id: el.dataset.id, sku: el.dataset.sku, title: el.dataset.title, price: Number(el.dataset.price||0)||undefined, currency: el.dataset.currency||'', qty:1, image: el.dataset.image||'' });
    }));
    document.getElementById('cart-btn')?.addEventListener('click', openDrawer);
    $$('#close-drawer').forEach(b=> b.addEventListener('click', closeDrawer));
    document.getElementById('send-rfq')?.addEventListener('click', sendRFQ);
  });
})();
