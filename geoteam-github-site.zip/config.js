
window.GEOTEAM_CONFIG = {
  MOCK: true,
  MAIL_API_URL: "https://mail-api-965282742784.europe-north1.run.app/send-email",
  MAIL_API_KEY: ""
};